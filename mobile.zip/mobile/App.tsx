import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { AuthProvider } from './src/context/AuthContext';
import { ZoneProvider } from './src/context/ZoneContext';
import AuthScreen from './src/screens/AuthScreen';
import MainTabs from './src/components/MainTabs';
import PermissionHandler from './src/components/PermissionHandler';
import { useAuth } from './src/context/AuthContext';

const Stack = createStackNavigator();

const AppNavigator = () => {
  const { user } = useAuth();

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {user ? (
        <Stack.Screen name="Main" component={MainTabs} />
      ) : (
        <Stack.Screen name="Auth" component={AuthScreen} />
      )}
    </Stack.Navigator>
  );
};

const App = () => {
  return (
    <PermissionHandler>
      <AuthProvider>
        <ZoneProvider>
          <NavigationContainer>
            <AppNavigator />
          </NavigationContainer>
        </ZoneProvider>
      </AuthProvider>
    </PermissionHandler>
  );
};

export default App;
