package com.silentzoneapp;

import android.content.Context;
import android.media.AudioManager;
import android.app.NotificationManager;
import android.os.Build;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.Promise;

public class RingerModeModule extends ReactContextBaseJavaModule {
    private static ReactApplicationContext reactContext;

    RingerModeModule(ReactApplicationContext context) {
        super(context);
        reactContext = context;
    }

    @Override
    public String getName() {
        return "RingerModeModule";
    }

    @ReactMethod
    public void setRingerMode(int mode, Promise promise) {
        try {
            AudioManager audioManager = (AudioManager) reactContext.getSystemService(Context.AUDIO_SERVICE);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                NotificationManager notificationManager = (NotificationManager) reactContext.getSystemService(Context.NOTIFICATION_SERVICE);
                if (!notificationManager.isNotificationPolicyAccessGranted()) {
                    promise.reject("PERMISSION_DENIED", "Do Not Disturb permission required");
                    return;
                }
            }
            
            // 0 = Silent, 1 = Vibrate, 2 = Normal
            audioManager.setRingerMode(mode);
            promise.resolve("Ringer mode changed successfully");
        } catch (Exception e) {
            promise.reject("ERROR", e.getMessage());
        }
    }

    @ReactMethod
    public void getRingerMode(Promise promise) {
        try {
            AudioManager audioManager = (AudioManager) reactContext.getSystemService(Context.AUDIO_SERVICE);
            int currentMode = audioManager.getRingerMode();
            promise.resolve(currentMode);
        } catch (Exception e) {
            promise.reject("ERROR", e.getMessage());
        }
    }
}