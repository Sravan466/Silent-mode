import React from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  Dimensions
} from 'react-native';
import { useAuth } from '../context/AuthContext';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

const ProfileScreen = () => {
  const { user, logout } = useAuth();

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Logout', style: 'destructive', onPress: logout }
      ]
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.logoSection}>
          <Text style={styles.logoIcon}>🔇</Text>
          <Text style={styles.title}>Profile</Text>
        </View>
      </View>

      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            {user?.username?.charAt(0).toUpperCase()}
          </Text>
        </View>
        <Text style={styles.username}>{user?.username}</Text>
        <Text style={styles.email}>{user?.email}</Text>
      </View>

      <View style={styles.menuSection}>
        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuIcon}>⚙️</Text>
          <Text style={styles.menuText}>Settings</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuIcon}>📊</Text>
          <Text style={styles.menuText}>Usage Statistics</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.menuItem}>
          <Text style={styles.menuIcon}>ℹ️</Text>
          <Text style={styles.menuText}>About</Text>
          <Text style={styles.menuArrow}>›</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutText}>Logout</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.footer}>
        <Text style={styles.version}>Silent Zone v1.0.0</Text>
        <Text style={styles.description}>Location-based phone silencing</Text>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: screenWidth * 0.05,
    paddingVertical: screenHeight * 0.025,
    paddingTop: screenHeight * 0.07,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  logoSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  logoIcon: {
    fontSize: Math.min(screenWidth * 0.07, 28),
  },
  title: {
    fontSize: Math.min(screenWidth * 0.07, 28),
    fontWeight: 'bold',
    color: '#1F2937',
  },
  profileCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    padding: screenWidth * 0.08,
    alignItems: 'center',
    margin: screenWidth * 0.04,
    borderRadius: 16,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.1)',
  },
  avatar: {
    width: Math.min(screenWidth * 0.24, 96),
    height: Math.min(screenWidth * 0.24, 96),
    borderRadius: Math.min(screenWidth * 0.12, 48),
    backgroundColor: '#8B5CF6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
  },
  avatarText: {
    fontSize: Math.min(screenWidth * 0.09, 36),
    fontWeight: 'bold',
    color: 'white',
  },
  username: {
    fontSize: Math.min(screenWidth * 0.06, 24),
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 8,
  },
  email: {
    fontSize: Math.min(screenWidth * 0.04, 16),
    color: '#6B7280',
    fontWeight: '500',
  },
  menuSection: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    margin: screenWidth * 0.04,
    borderRadius: 16,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.1)',
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: screenWidth * 0.05,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
    minHeight: 60,
  },
  menuIcon: {
    fontSize: Math.min(screenWidth * 0.05, 20),
    marginRight: 16,
    width: 24,
  },
  menuText: {
    flex: 1,
    fontSize: Math.min(screenWidth * 0.04, 16),
    fontWeight: '500',
    color: '#1F2937',
  },
  menuArrow: {
    fontSize: Math.min(screenWidth * 0.05, 20),
    color: '#9CA3AF',
  },
  section: {
    margin: screenWidth * 0.04,
  },
  logoutButton: {
    backgroundColor: '#EF4444',
    padding: screenHeight * 0.02,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
    minHeight: 50,
    justifyContent: 'center',
  },
  logoutText: {
    color: 'white',
    fontSize: Math.min(screenWidth * 0.04, 16),
    fontWeight: '600',
  },
  footer: {
    padding: screenWidth * 0.08,
    alignItems: 'center',
    gap: 8,
  },
  version: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#9CA3AF',
    fontWeight: '600',
  },
  description: {
    fontSize: Math.min(screenWidth * 0.03, 12),
    color: '#6B7280',
  },
});

export default ProfileScreen;