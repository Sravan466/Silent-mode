import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ScrollView,
  Slider,
  ActivityIndicator,
  Dimensions
} from 'react-native';
import MapView, { Marker, Circle } from 'react-native-maps';
import { useZones } from '../context/ZoneContext';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

const AddZoneScreen = () => {
  const [name, setName] = useState('');
  const [mode, setMode] = useState('silent');
  const [radius, setRadius] = useState(100);
  const [location, setLocation] = useState(null);
  const [loading, setLoading] = useState(false);
  const [userLocation, setUserLocation] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [searching, setSearching] = useState(false);
  const mapRef = useRef(null);
  
  const { createZone } = useZones();

  useEffect(() => {
    getUserLocation();
  }, []);

  const getUserLocation = () => {
    navigator.geolocation?.getCurrentPosition(
      (position) => {
        const userLoc = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        };
        setUserLocation(userLoc);
      },
      (error) => {
        // Default to Hyderabad
        setUserLocation({ latitude: 17.3850, longitude: 78.4867 });
      }
    );
  };

  const searchLocation = async (query) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setSearching(true);
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5&addressdetails=1`
      );
      const data = await response.json();
      setSearchResults(data);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setSearching(false);
    }
  };

  const selectSearchResult = (result) => {
    const newLocation = {
      latitude: parseFloat(result.lat),
      longitude: parseFloat(result.lon)
    };
    setLocation(newLocation);
    setSearchQuery(result.display_name.split(',').slice(0, 2).join(','));
    setSearchResults([]);
    
    // Animate map to location
    mapRef.current?.animateToRegion({
      ...newLocation,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });
  };

  const handleSave = async () => {
    if (!name.trim()) {
      Alert.alert('Error', 'Please enter a zone name');
      return;
    }

    if (!location) {
      Alert.alert('Error', 'Please select a location on the map');
      return;
    }

    if (radius < 10 || radius > 1000) {
      Alert.alert('Error', 'Radius must be between 10 and 1000 meters');
      return;
    }

    setLoading(true);
    try {
      await createZone({
        name: name.trim(),
        latitude: location.latitude,
        longitude: location.longitude,
        radius: radius,
        mode
      });

      Alert.alert('Success', 'Zone created successfully!', [
        { text: 'OK', onPress: () => {
          setName('');
          setLocation(null);
          setRadius(100);
          setMode('silent');
          setSearchQuery('');
        }}
      ]);
    } catch (error) {
      Alert.alert('Error', 'Failed to create zone');
    } finally {
      setLoading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Create New Zone</Text>
        <Text style={styles.subtitle}>Set up location-based phone silencing</Text>
      </View>

      <View style={styles.form}>
        <View style={styles.formGroup}>
          <Text style={styles.label}>Zone Name</Text>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              placeholder="e.g., Office, Library, Hospital"
              placeholderTextColor="#9CA3AF"
              value={name}
              onChangeText={setName}
            />
          </View>
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Select Location</Text>
          <Text style={styles.hint}>Search or tap on the map to choose your silent zone location</Text>
          
          <View style={styles.searchContainer}>
            <TextInput
              style={styles.searchInput}
              placeholder="Search for a location..."
              placeholderTextColor="#9CA3AF"
              value={searchQuery}
              onChangeText={(text) => {
                setSearchQuery(text);
                searchLocation(text);
              }}
            />
            {searching && <ActivityIndicator size="small" color="#8B5CF6" style={styles.searchLoader} />}
          </View>

          {searchResults.length > 0 && (
            <View style={styles.searchResults}>
              {searchResults.map((result, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.searchResultItem}
                  onPress={() => selectSearchResult(result)}
                >
                  <Text style={styles.searchResultText}>
                    {result.display_name.split(',').slice(0, 3).join(',')}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          )}
        </View>

        <View style={styles.mapContainer}>
          <MapView
            ref={mapRef}
            style={styles.map}
            initialRegion={{
              latitude: userLocation?.latitude || 17.3850,
              longitude: userLocation?.longitude || 78.4867,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01,
            }}
            onPress={(event) => {
              const { latitude, longitude } = event.nativeEvent.coordinate;
              setLocation({ latitude, longitude });
            }}
          >
            {location && (
              <>
                <Marker coordinate={location} />
                <Circle
                  center={location}
                  radius={radius}
                  fillColor="rgba(139, 92, 246, 0.2)"
                  strokeColor="rgba(139, 92, 246, 0.8)"
                  strokeWidth={2}
                />
              </>
            )}
          </MapView>
        </View>

        <View style={styles.formRow}>
          <View style={styles.formGroup}>
            <Text style={styles.label}>Zone Radius</Text>
            <View style={styles.radiusControl}>
              <Slider
                style={styles.radiusSlider}
                minimumValue={10}
                maximumValue={1000}
                value={radius}
                onValueChange={setRadius}
                step={10}
                minimumTrackTintColor="#8B5CF6"
                maximumTrackTintColor="#E5E7EB"
                thumbStyle={{ backgroundColor: '#8B5CF6' }}
              />
              <View style={styles.radiusDisplay}>
                <Text style={styles.radiusValue}>{Math.round(radius)}</Text>
                <Text style={styles.radiusUnit}>meters</Text>
              </View>
            </View>
          </View>
        </View>

        <View style={styles.formGroup}>
          <Text style={styles.label}>Audio Mode</Text>
          <View style={styles.modeCards}>
            <TouchableOpacity
              style={[styles.modeCard, mode === 'silent' && styles.modeCardSelected]}
              onPress={() => setMode('silent')}
            >
              <Text style={styles.modeCardIcon}>🔇</Text>
              <Text style={styles.modeCardTitle}>Silent</Text>
              <Text style={styles.modeCardDesc}>Complete silence</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.modeCard, mode === 'vibrate' && styles.modeCardSelected]}
              onPress={() => setMode('vibrate')}
            >
              <Text style={styles.modeCardIcon}>📳</Text>
              <Text style={styles.modeCardTitle}>Vibrate</Text>
              <Text style={styles.modeCardDesc}>Vibration only</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.createButton, loading && styles.createButtonDisabled]}
          onPress={handleSave}
          disabled={loading}
        >
          <Text style={styles.createButtonText}>
            {loading ? 'Creating Zone...' : '+ Create Zone'}
          </Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: screenWidth * 0.05,
    paddingVertical: screenHeight * 0.025,
    paddingTop: screenHeight * 0.07,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
  },
  title: {
    fontSize: Math.min(screenWidth * 0.07, 28),
    fontWeight: 'bold',
    color: '#1F2937',
  },
  subtitle: {
    fontSize: Math.min(screenWidth * 0.04, 16),
    color: '#6B7280',
    marginTop: 8,
  },
  form: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    padding: screenWidth * 0.05,
    margin: screenWidth * 0.04,
    borderRadius: 16,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  formGroup: {
    marginBottom: screenHeight * 0.03,
  },
  label: {
    fontSize: Math.min(screenWidth * 0.04, 16),
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 8,
  },
  inputContainer: {
    position: 'relative',
  },
  input: {
    backgroundColor: '#F9FAFB',
    borderWidth: 2,
    borderColor: '#E5E7EB',
    padding: screenHeight * 0.02,
    borderRadius: 12,
    fontSize: Math.min(screenWidth * 0.04, 16),
    color: '#1F2937',
    minHeight: 50,
  },
  hint: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#6B7280',
    marginBottom: 12,
    lineHeight: 20,
  },
  searchContainer: {
    position: 'relative',
    marginBottom: 12,
  },
  searchInput: {
    backgroundColor: '#F9FAFB',
    borderWidth: 2,
    borderColor: '#E5E7EB',
    padding: screenHeight * 0.02,
    borderRadius: 12,
    fontSize: Math.min(screenWidth * 0.04, 16),
    color: '#1F2937',
    minHeight: 50,
  },
  searchLoader: {
    position: 'absolute',
    right: 16,
    top: screenHeight * 0.02,
  },
  searchResults: {
    backgroundColor: 'white',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
    marginBottom: 12,
    maxHeight: screenHeight * 0.25,
  },
  searchResultItem: {
    padding: screenHeight * 0.02,
    borderBottomWidth: 1,
    borderBottomColor: '#F3F4F6',
    minHeight: 50,
    justifyContent: 'center',
  },
  searchResultText: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#1F2937',
  },
  mapContainer: {
    height: Math.min(screenHeight * 0.4, 300),
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: screenHeight * 0.03,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 3,
  },
  map: {
    flex: 1,
  },
  formRow: {
    marginBottom: screenHeight * 0.03,
  },
  radiusControl: {
    gap: 12,
  },
  radiusSlider: {
    width: '100%',
    height: 40,
  },
  radiusDisplay: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'baseline',
    gap: 4,
  },
  radiusValue: {
    fontSize: Math.min(screenWidth * 0.06, 24),
    fontWeight: 'bold',
    color: '#8B5CF6',
  },
  radiusUnit: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#6B7280',
    fontWeight: '500',
  },
  modeCards: {
    flexDirection: screenWidth < 400 ? 'column' : 'row',
    gap: 12,
  },
  modeCard: {
    flex: screenWidth < 400 ? 0 : 1,
    padding: screenHeight * 0.02,
    borderRadius: 12,
    backgroundColor: '#F9FAFB',
    borderWidth: 2,
    borderColor: '#E5E7EB',
    alignItems: 'center',
    gap: 8,
    minHeight: 80,
    justifyContent: 'center',
  },
  modeCardSelected: {
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    borderColor: '#8B5CF6',
  },
  modeCardIcon: {
    fontSize: Math.min(screenWidth * 0.06, 24),
  },
  modeCardTitle: {
    fontSize: Math.min(screenWidth * 0.04, 16),
    fontWeight: '600',
    color: '#1F2937',
  },
  modeCardDesc: {
    fontSize: Math.min(screenWidth * 0.03, 12),
    color: '#6B7280',
  },
  buttonContainer: {
    padding: screenWidth * 0.05,
  },
  createButton: {
    backgroundColor: '#8B5CF6',
    padding: screenHeight * 0.02,
    borderRadius: 12,
    alignItems: 'center',
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 5,
    minHeight: 50,
    justifyContent: 'center',
  },
  createButtonDisabled: {
    backgroundColor: '#D1D5DB',
    shadowOpacity: 0,
  },
  createButtonText: {
    color: 'white',
    fontSize: Math.min(screenWidth * 0.04, 16),
    fontWeight: '600',
  },
});

export default AddZoneScreen;