import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Switch,
  ActivityIndicator,
  Dimensions
} from 'react-native';
import { useZones } from '../context/ZoneContext';

const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

const ZonesScreen = () => {
  const { zones, loading, fetchZones, updateZone, deleteZone } = useZones();
  const [zoneAddresses, setZoneAddresses] = useState({});

  useEffect(() => {
    fetchZones();
    loadAddresses();
  }, [zones]);

  const getAddressFromCoordinates = async (lat, lng) => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&addressdetails=1`
      );
      const data = await response.json();
      return data.display_name || `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    } catch (error) {
      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    }
  };

  const loadAddresses = async () => {
    const addresses = {};
    for (const zone of zones) {
      const lat = zone.location.coordinates[1];
      const lng = zone.location.coordinates[0];
      addresses[zone._id] = await getAddressFromCoordinates(lat, lng);
    }
    setZoneAddresses(addresses);
  };

  const getShortAddress = (fullAddress) => {
    if (!fullAddress) return 'Loading...';
    const parts = fullAddress.split(',');
    return parts.slice(0, 2).join(',').trim();
  };

  const handleToggleZone = async (zone) => {
    try {
      await updateZone(zone._id, {
        ...zone,
        latitude: zone.location.coordinates[1],
        longitude: zone.location.coordinates[0],
        isActive: !zone.isActive
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to update zone');
    }
  };

  const handleDeleteZone = (zone) => {
    Alert.alert(
      'Delete Zone',
      `Are you sure you want to delete "${zone.name}"?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => deleteZone(zone._id)
        }
      ]
    );
  };

  const renderZone = ({ item: zone }) => (
    <View style={styles.zoneCard}>
      <View style={styles.zoneHeader}>
        <View style={styles.zoneIcon}>
          <Text style={styles.zoneIconText}>
            {zone.mode === 'silent' ? '🔇' : '📳'}
          </Text>
        </View>
        <View style={styles.zoneInfo}>
          <Text style={styles.zoneName}>{zone.name}</Text>
          <Text style={styles.zoneMode}>
            {zone.mode === 'silent' ? 'Silent Mode' : 'Vibrate Mode'}
          </Text>
        </View>
        <View style={styles.zoneStatus}>
          <View style={[styles.statusBadge, zone.isActive && styles.statusBadgeActive]}>
            <Text style={[styles.statusText, zone.isActive && styles.statusTextActive]}>
              {zone.isActive ? 'Active' : 'Inactive'}
            </Text>
          </View>
        </View>
      </View>
      
      <View style={styles.zoneDetails}>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Radius</Text>
          <Text style={styles.detailValue}>{zone.radius}m</Text>
        </View>
        <View style={styles.detailItem}>
          <Text style={styles.detailLabel}>Location</Text>
          <Text style={styles.detailValue}>
            {getShortAddress(zoneAddresses[zone._id])}
          </Text>
        </View>
      </View>

      <View style={styles.zoneActions}>
        <TouchableOpacity style={styles.editButton}>
          <Text style={styles.editButtonText}>Edit</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => handleDeleteZone(zone)}
        >
          <Text style={styles.deleteButtonText}>Delete</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  if (loading) {
    return (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color="#8B5CF6" />
        <Text style={styles.loadingText}>Loading zones...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My Silent Zones</Text>
        <View style={styles.headerActions}>
          <Text style={styles.zoneCount}>{zones.length} zones</Text>
        </View>
      </View>

      {zones.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyIcon}>📍</Text>
          <Text style={styles.emptyTitle}>Your Zones Will Appear Here</Text>
          <Text style={styles.emptySubtext}>
            Add a zone to automatically silence your phone at work, school, or any location.
          </Text>
        </View>
      ) : (
        <FlatList
          data={zones}
          renderItem={renderZone}
          keyExtractor={(item) => item._id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F8FAFC',
  },
  header: {
    paddingHorizontal: screenWidth * 0.05,
    paddingVertical: screenHeight * 0.025,
    paddingTop: screenHeight * 0.07,
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    borderBottomWidth: 1,
    borderBottomColor: '#E5E7EB',
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  title: {
    fontSize: Math.min(screenWidth * 0.07, 28),
    fontWeight: 'bold',
    color: '#1F2937',
  },
  headerActions: {
    alignItems: 'flex-end',
  },
  zoneCount: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#6B7280',
    fontWeight: '500',
  },
  listContainer: {
    padding: screenWidth * 0.05,
  },
  zoneCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.95)',
    padding: screenWidth * 0.05,
    borderRadius: 16,
    marginBottom: 16,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
    borderWidth: 1,
    borderColor: 'rgba(139, 92, 246, 0.1)',
  },
  zoneHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: screenHeight * 0.02,
  },
  zoneIcon: {
    width: Math.min(screenWidth * 0.12, 48),
    height: Math.min(screenWidth * 0.12, 48),
    borderRadius: Math.min(screenWidth * 0.06, 24),
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  zoneIconText: {
    fontSize: Math.min(screenWidth * 0.05, 20),
  },
  zoneInfo: {
    flex: 1,
  },
  zoneName: {
    fontSize: Math.min(screenWidth * 0.045, 18),
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 4,
  },
  zoneMode: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#6B7280',
    fontWeight: '500',
  },
  zoneStatus: {
    alignItems: 'flex-end',
  },
  statusBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
  },
  statusBadgeActive: {
    backgroundColor: 'rgba(34, 197, 94, 0.1)',
  },
  statusText: {
    fontSize: Math.min(screenWidth * 0.03, 12),
    fontWeight: '600',
    color: '#6B7280',
  },
  statusTextActive: {
    color: '#22C55E',
  },
  zoneDetails: {
    marginBottom: screenHeight * 0.02,
    gap: 8,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  detailLabel: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#6B7280',
    fontWeight: '500',
  },
  detailValue: {
    fontSize: Math.min(screenWidth * 0.035, 14),
    color: '#1F2937',
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  zoneActions: {
    flexDirection: 'row',
    gap: 12,
  },
  editButton: {
    flex: 1,
    paddingVertical: screenHeight * 0.015,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(139, 92, 246, 0.1)',
    borderRadius: 8,
    alignItems: 'center',
    minHeight: 44,
    justifyContent: 'center',
  },
  editButtonText: {
    color: '#8B5CF6',
    fontSize: Math.min(screenWidth * 0.035, 14),
    fontWeight: '600',
  },
  deleteButton: {
    flex: 1,
    paddingVertical: screenHeight * 0.015,
    paddingHorizontal: 16,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderRadius: 8,
    alignItems: 'center',
    minHeight: 44,
    justifyContent: 'center',
  },
  deleteButtonText: {
    color: '#EF4444',
    fontSize: Math.min(screenWidth * 0.035, 14),
    fontWeight: '600',
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    fontSize: Math.min(screenWidth * 0.04, 16),
    color: '#6B7280',
    fontWeight: '500',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: screenWidth * 0.1,
    gap: 16,
  },
  emptyIcon: {
    fontSize: Math.min(screenWidth * 0.16, 64),
    marginBottom: 8,
  },
  emptyTitle: {
    fontSize: Math.min(screenWidth * 0.05, 20),
    fontWeight: '600',
    color: '#1F2937',
    textAlign: 'center',
  },
  emptySubtext: {
    fontSize: Math.min(screenWidth * 0.04, 16),
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 24,
  },
});

export default ZonesScreen;