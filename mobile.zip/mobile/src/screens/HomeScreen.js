import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Switch,
  ScrollView,
  TouchableOpacity,
  Alert
} from 'react-native';
import { useZones } from '../context/ZoneContext';
import { useAuth } from '../context/AuthContext';

const HomeScreen = () => {
  const [serviceEnabled, setServiceEnabled] = useState(true);
  const { zones, fetchZones } = useZones();
  const { user } = useAuth();

  useEffect(() => {
    fetchZones();
  }, []);

  const toggleService = async (value) => {
    setServiceEnabled(value);
    if (value) {
      Alert.alert('Service Enabled', 'Silent Zone monitoring is now active');
    } else {
      Alert.alert('Service Disabled', 'Silent Zone monitoring is now inactive');
    }
  };

  const activeZones = zones.filter(zone => zone.isActive);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Welcome, {user?.username}!</Text>
        <Text style={styles.subtitle}>Silent Zone Auto Mode</Text>
      </View>

      <View style={styles.card}>
        <View style={styles.serviceToggle}>
          <Text style={styles.cardTitle}>Service Status</Text>
          <Switch
            value={serviceEnabled}
            onValueChange={toggleService}
            trackColor={{ false: '#767577', true: '#81b0ff' }}
            thumbColor={serviceEnabled ? '#007AFF' : '#f4f3f4'}
          />
        </View>
        <Text style={styles.statusText}>
          {serviceEnabled ? 'Monitoring Active' : 'Monitoring Disabled'}
        </Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Zone Summary</Text>
        <View style={styles.stats}>
          <View style={styles.stat}>
            <Text style={styles.statNumber}>{zones.length}</Text>
            <Text style={styles.statLabel}>Total Zones</Text>
          </View>
          <View style={styles.stat}>
            <Text style={styles.statNumber}>{activeZones.length}</Text>
            <Text style={styles.statLabel}>Active Zones</Text>
          </View>
        </View>
      </View>

      {activeZones.length > 0 && (
        <View style={styles.card}>
          <Text style={styles.cardTitle}>Active Zones</Text>
          {activeZones.slice(0, 3).map((zone) => (
            <View key={zone._id} style={styles.zoneItem}>
              <Text style={styles.zoneName}>{zone.name}</Text>
              <Text style={styles.zoneMode}>
                {zone.mode === 'silent' ? '🔇 Silent' : '📳 Vibrate'}
              </Text>
            </View>
          ))}
          {activeZones.length > 3 && (
            <Text style={styles.moreText}>
              +{activeZones.length - 3} more zones
            </Text>
          )}
        </View>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 20,
  },
  header: {
    marginBottom: 20,
    paddingTop: 40,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginTop: 5,
  },
  card: {
    backgroundColor: 'white',
    padding: 20,
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 15,
    color: '#333',
  },
  serviceToggle: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  statusText: {
    fontSize: 14,
    color: '#666',
  },
  stats: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  stat: {
    alignItems: 'center',
  },
  statNumber: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#007AFF',
  },
  statLabel: {
    fontSize: 12,
    color: '#666',
    marginTop: 5,
  },
  zoneItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  zoneName: {
    fontSize: 16,
    color: '#333',
  },
  zoneMode: {
    fontSize: 14,
    color: '#666',
  },
  moreText: {
    fontSize: 14,
    color: '#007AFF',
    textAlign: 'center',
    marginTop: 10,
  },
});

export default HomeScreen;