import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Text, Dimensions } from 'react-native';
import HomeScreen from '../screens/HomeScreen';
import ZonesScreen from '../screens/ZonesScreen';
import AddZoneScreen from '../screens/AddZoneScreen';
import ProfileScreen from '../screens/ProfileScreen';

const Tab = createBottomTabNavigator();
const { width: screenWidth, height: screenHeight } = Dimensions.get('window');

const MainTabs = () => {
  return (
    <Tab.Navigator
      screenOptions={{
        tabBarActiveTintColor: '#8B5CF6',
        tabBarInactiveTintColor: '#9CA3AF',
        headerShown: false,
        tabBarStyle: {
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          borderTopWidth: 1,
          borderTopColor: 'rgba(139, 92, 246, 0.1)',
          paddingTop: 8,
          paddingBottom: 8,
          height: Math.max(screenHeight * 0.1, 70),
        },
        tabBarLabelStyle: {
          fontSize: Math.min(screenWidth * 0.03, 12),
          fontWeight: '600',
          marginTop: 4,
        },
      }}
    >
      <Tab.Screen 
        name="Zones" 
        component={ZonesScreen}
        options={{
          tabBarLabel: 'My Zones',
          tabBarIcon: ({ color, focused }) => (
            <Text style={{ fontSize: Math.min(screenWidth * 0.05, 20), color }}>📍</Text>
          ),
        }}
      />
      <Tab.Screen 
        name="AddZone" 
        component={AddZoneScreen}
        options={{
          tabBarLabel: 'Add Zone',
          tabBarIcon: ({ color, focused }) => (
            <Text style={{ fontSize: Math.min(screenWidth * 0.05, 20), color }}>+</Text>
          ),
        }}
      />
      <Tab.Screen 
        name="Profile" 
        component={ProfileScreen}
        options={{
          tabBarLabel: 'Profile',
          tabBarIcon: ({ color, focused }) => (
            <Text style={{ fontSize: Math.min(screenWidth * 0.05, 20), color }}>👤</Text>
          ),
        }}
      />
    </Tab.Navigator>
  );
};

export default MainTabs;