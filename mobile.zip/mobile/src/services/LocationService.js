import { NativeModules, PermissionsAndroid, Platform } from 'react-native';
import Geolocation from '@react-native-community/geolocation';

const { RingerModeModule } = NativeModules;

class LocationService {
  constructor() {
    this.watchId = null;
    this.zones = [];
    this.currentZone = null;
    this.originalRingerMode = 2; // Normal mode
  }

  async requestPermissions() {
    if (Platform.OS === 'android') {
      const granted = await PermissionsAndroid.requestMultiple([
        PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION,
        PermissionsAndroid.PERMISSIONS.ACCESS_BACKGROUND_LOCATION,
      ]);
      
      return granted['android.permission.ACCESS_FINE_LOCATION'] === 'granted' &&
             granted['android.permission.ACCESS_BACKGROUND_LOCATION'] === 'granted';
    }
    return true;
  }

  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // Earth's radius in meters
    const φ1 = lat1 * Math.PI/180;
    const φ2 = lat2 * Math.PI/180;
    const Δφ = (lat2-lat1) * Math.PI/180;
    const Δλ = (lon2-lon1) * Math.PI/180;

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));

    return R * c; // Distance in meters
  }

  async checkZones(position) {
    const { latitude, longitude } = position.coords;
    
    for (const zone of this.zones) {
      const zoneLat = zone.location.coordinates[1];
      const zoneLng = zone.location.coordinates[0];
      const distance = this.calculateDistance(latitude, longitude, zoneLat, zoneLng);
      
      if (distance <= zone.radius && zone.isActive) {
        // Entering zone
        if (this.currentZone !== zone._id) {
          this.currentZone = zone._id;
          await this.enterZone(zone);
        }
        return;
      }
    }
    
    // Not in any zone - restore original mode
    if (this.currentZone) {
      this.currentZone = null;
      await this.exitZone();
    }
  }

  async enterZone(zone) {
    try {
      // Store original ringer mode
      this.originalRingerMode = await RingerModeModule.getRingerMode();
      
      // Set new ringer mode
      const newMode = zone.mode === 'silent' ? 0 : 1; // 0=Silent, 1=Vibrate
      await RingerModeModule.setRingerMode(newMode);
      
      console.log(`Entered zone: ${zone.name}, switched to ${zone.mode} mode`);
    } catch (error) {
      console.error('Error entering zone:', error);
    }
  }

  async exitZone() {
    try {
      // Restore original ringer mode
      await RingerModeModule.setRingerMode(this.originalRingerMode);
      console.log('Exited zone, restored original ringer mode');
    } catch (error) {
      console.error('Error exiting zone:', error);
    }
  }

  startTracking(zones) {
    this.zones = zones;
    
    this.watchId = Geolocation.watchPosition(
      (position) => {
        this.checkZones(position);
      },
      (error) => {
        console.error('Location error:', error);
      },
      {
        enableHighAccuracy: true,
        distanceFilter: 10, // Update every 10 meters
        interval: 30000, // Check every 30 seconds
        fastestInterval: 10000, // Fastest update 10 seconds
      }
    );
  }

  stopTracking() {
    if (this.watchId) {
      Geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
  }

  updateZones(zones) {
    this.zones = zones;
  }
}

export default new LocationService();