import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const API_BASE_URL = 'https://silent-mode-backend.onrender.com/api';

const api = axios.create({
  baseURL: API_BASE_URL,
});

api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const authService = {
  login: async (email, password) => {
    const response = await api.post('/auth/login', { email, password });
    return response.data;
  },

  register: async (username, email, password) => {
    const response = await api.post('/auth/register', { username, email, password });
    return response.data;
  },

  getProfile: async () => {
    const response = await api.get('/auth/profile');
    return response.data;
  }
};

export const zoneService = {
  getZones: async () => {
    const response = await api.get('/zones');
    return response.data;
  },

  createZone: async (zoneData) => {
    const response = await api.post('/zones', zoneData);
    return response.data;
  },

  updateZone: async (id, zoneData) => {
    const response = await api.put(`/zones/${id}`, zoneData);
    return response.data;
  },

  deleteZone: async (id) => {
    const response = await api.delete(`/zones/${id}`);
    return response.data;
  }
};