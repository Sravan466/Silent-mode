import React, { createContext, useContext, useState, useEffect } from 'react';
import { zoneService } from '../services/api';
import LocationService from '../services/LocationService';

const ZoneContext = createContext();

export const useZones = () => {
  const context = useContext(ZoneContext);
  if (!context) {
    throw new Error('useZones must be used within ZoneProvider');
  }
  return context;
};

export const ZoneProvider = ({ children }) => {
  const [zones, setZones] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Start location tracking when zones are available
    if (zones.length > 0) {
      LocationService.requestPermissions().then(granted => {
        if (granted) {
          LocationService.startTracking(zones);
        }
      });
    }
    
    return () => {
      LocationService.stopTracking();
    };
  }, [zones]);

  const fetchZones = async () => {
    try {
      setLoading(true);
      const data = await zoneService.getZones();
      setZones(data);
      LocationService.updateZones(data);
    } catch (error) {
      console.error('Error fetching zones:', error);
    } finally {
      setLoading(false);
    }
  };

  const createZone = async (zoneData) => {
    try {
      const newZone = await zoneService.createZone(zoneData);
      const updatedZones = [...zones, newZone];
      setZones(updatedZones);
      LocationService.updateZones(updatedZones);
      return newZone;
    } catch (error) {
      throw error;
    }
  };

  const updateZone = async (id, zoneData) => {
    try {
      const updatedZone = await zoneService.updateZone(id, zoneData);
      const updatedZones = zones.map(zone => 
        zone._id === id ? updatedZone : zone
      );
      setZones(updatedZones);
      LocationService.updateZones(updatedZones);
      return updatedZone;
    } catch (error) {
      throw error;
    }
  };

  const deleteZone = async (id) => {
    try {
      await zoneService.deleteZone(id);
      const updatedZones = zones.filter(zone => zone._id !== id);
      setZones(updatedZones);
      LocationService.updateZones(updatedZones);
    } catch (error) {
      throw error;
    }
  };

  const value = {
    zones,
    loading,
    fetchZones,
    createZone,
    updateZone,
    deleteZone
  };

  return (
    <ZoneContext.Provider value={value}>
      {children}
    </ZoneContext.Provider>
  );
};